days = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

for i in range(1, len(days)):
    days[i] = days[i-1] + days[i]

T = int(input())

for tc in range(1, T+1)
    answer = 0

    # 3 1 3 31
    m1, d1, m2, d2 = map(int, input().split()) #"3 1 3 31"

    answer = (days[m2-1] + d2)
    answer = answer - (days[m1-1] + d1)
    answer = answer + 1

    print(f"#{tc} {answer}")