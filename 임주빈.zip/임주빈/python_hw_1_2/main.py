'''
- 파이썬 파일의 이름을 오류 화면을 확인하여 적절한 파일명으로 변경한다.
- 수정 사항을 반영하기 위하여 commit을 진행한다.
- 위 과정을 반드시 온라인 실습실에서 진행하지는 않아도 된다.
- 필요하다면, local에서 repository를 clone 받아서 진행한다.
'''
word = 'Hello, World!'

print(word)

