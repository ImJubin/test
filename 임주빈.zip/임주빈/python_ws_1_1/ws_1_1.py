n = '홍길동'
a = 20
s = '이름 : '
s2 = '나이 : '
s3 = '학생 정보를 출력합니다.'
s4 = '각각의 정보는 다음과 같습니다'
s5 = '출력 완료'

print(s3)
print(s4)
print(s, n)
print(s2, a)
print(s4)
