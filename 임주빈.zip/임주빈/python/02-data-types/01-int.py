# 정수 자료형
a = 10
b = 0
c = -5


# 진수 표현
# 2진수(binary)
print(0b10)  # 2

# 8진수(octal)
print(0o30)  # 24

# 16진수(hexadecimal)
print(0x10)  # 16
