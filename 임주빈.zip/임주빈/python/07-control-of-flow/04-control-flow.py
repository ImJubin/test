# break
for i in range(10):
    if i == 5:
        break
    print(i)


# continue
for i in range(10):
    if i % 2 == 0:
        continue
    print(i)


# pass
for i in range(10):
    pass


def my_func(a):
    pass
