print(type('1')) # <class 'str'>
print(type[1.2]) # class list
print(help(str))


#클래스 파트에서 이어서 진행할 것임

def add(a,b):
    return a + b

class calculator:
    def add(self, a, b):
        return a + b
    
# 함수 호출
add(1, 2)

# 메서드 호출
a = calculator()
a.add(1, 2)
