import math

print(math.pi)

print(math.sqrt(4))