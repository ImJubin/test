def mod(x, y):
    return x % y
