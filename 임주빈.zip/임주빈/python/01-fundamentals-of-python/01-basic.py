print('Hello, World')
