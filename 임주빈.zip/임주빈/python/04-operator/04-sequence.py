# 시퀀스형 연산자

print('Gildong' + ' Hong')  #
print('Hi' * 5)  #

print([1, 2] + ['a', 'b'])  #
print([1, 2] * 2)  #
