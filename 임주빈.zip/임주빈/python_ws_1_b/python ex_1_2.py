# 아래에 코드를 작성하시오.

korea = "한글"
english = "english"
number = 3

print (f"{korea}과 {english}")

print (korea*number)
