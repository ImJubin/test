# # 아래 클래스를 수정하시오.
# class StringRepeater:

#     def __init__(self, hi):

#         self.message = hi
#         pass

#     def repeat_string(self, repeat):
#         for i in range(repeat):
#             print(self.message)  


# repeater1 = StringRepeater("Hello") # (객체)생성자 함수
# repeater1.repeat_string(3)
# StringRepeater.repeat_string(repeater1, 3, "Hello")


# 튜플 리스트 셋 딕셔너리

class StringRepeater:

    def __init__(self, hi):

        self.message = hi

    def repeat_string(self, repeat):
        for i in range(repeat):
            print(self.message)

repeater1 = StringRepeater("Hello") # (객체)생성자 함수
repeater1.repeat_string(3)
# StringRepeater.repeat_string(repeater1, 3, "Hello")