if []:
    print("참이니?")

