# 아래 함수를 수정하시오.
def find_min_max(word):
    return (min(word), max(word))
    
result = find_min_max([3, 1, 7, 2, 5])

print(result)  # (1, 7)

