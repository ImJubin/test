a = 5

def make_sum(a, b):
    return a+b
