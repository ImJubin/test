# 아래 함수를 수정하시오.
def add_numbers(a, b):
    print(a+b)
    return a + b




# 수정한 add_numbers() 함수를 호출하시오.
c = add_numbers(3, 5)