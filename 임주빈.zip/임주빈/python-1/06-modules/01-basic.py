import math
import random
import datetime

print(math.pi)
print(math.sqrt(4))

print(random.randint(1, 10))

now = datetime.datetime.now()
print(now)
