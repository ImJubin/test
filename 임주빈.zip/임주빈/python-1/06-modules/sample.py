# import my_math

# print(my_math.add(1, 2))

from my_package.math import my_math
from my_package.statistics import tools


print(my_math.add(1, 2))
print(tools.mod(1, 2))
