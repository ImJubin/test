my_str = "hello"

print(my_str[-1:-5:-1])  # e

a=5
b=5
c=5
d=5
e=5

