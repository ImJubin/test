# 사과는 영어로 apple
# 바나나는 영어로 banana
# 키위는 영어로 kiwi

a = "사과는 영어로 apple"
b = "바나나는 영어로 banana"
c = "키위는 영어로 kiwi"

print(a)
print(b)
print(c)

