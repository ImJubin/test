a = []

# while 조건식:
#     실행문
n = 1
while n <= 100:
    
    a.append(n)

    n += 1  # n += 1

print()

# for i in range(100):
#     print(a[i])
    
print()


# 1. 1부터 100 이전까지 숫자를 돌면서 순회하도록 반복문을 구성 > for - range 활용
# 2. 1번에서 도는 숫자를 i라고 명명한다. 그 i는 그 숫자가 의미가 있다기보다 인덱스 용도로 사용된다.
# 3. 인덱스의 타겟은 a라는 리스트이다.
# 4. 인덱싱은 [] 연산자로 한다.
# 5. 해당 인덱싱한 a[i] 값을 print 한다.

# 역순으로 뽑아보세요

# ㄱ. 반복문 활용
# for i in range(100):
#     print(a[-1-i])

# ㄴ. 슬라이싱 활용
# print(a[::-1])
# print(a[99::-1])
# print(a[-1::-1])

# ㄷ. range 활용
# for i in range(99,-1,-1):
#     print(a[i])


# 홀수 인덱스만 뽑아보세요
# print(a[1::2])

# 홀수만 뽑아보세요

# for i in range(100):
#     if a[i] % 2 == 1:
#         print(a[i], end=" ")
# print()


# 6번 인덱스부터 11번 인덱스까지 더한 값을 출력해주세요

# ㄱ. for-range를 이용
sum_a = 0
for i in range(6,12):
    sum_a += a[i]
print(sum_a)

# ㄴ. 슬라이싱을 이용
print(a[6:12:1])
b = sum(a[6:12:1])
print(b)


# a의 모든 요소에서 10을 뺀 수를 b에 넣고 출력해주세요


