def BubbleSort(a, N) : 	# 정렬할 List, N 원소 수
    for i in range(N-1, 0, -1) : # 범위의 끝 위치
        for j in range(i) :		# 비교할 왼쪽 원소 인덱스 j
            if a[j] > a[j+1] :
                a[j], a[j+1] = a[j+1], a[j] 

BubbleSort(arr, N)
print(arr)




#평균 = 총합 / 리스트 길이
#       >sum, len 없이 총합, 길이를 구하려면? 반복문을 돌아야해(구조)
#       >그 총합과 길이는 변수가 필요하겠군(data)
#최소, 최대
#       >min max 없이 최소 치대 구하려면? 반복문을 돌아야 해 (구조)
#       >최소, 최대 변수ㅏㄱ 필요하겠군(data)