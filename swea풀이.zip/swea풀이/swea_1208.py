# 최댓값 - 최솟값 = 차이
# 9 - 1 = 8
# 8 - 2 = 6
# 8 - 2 = 6
# 8 - 2 = 6
# .....



def Counting_Sort(DATA, TEMP, k):
# DATA [] -- 입력 배열(원소는 0 이상 k이하 정수)
# TEMP [] -- 정렬된 배열.
# COUNTS [] -- 카운트 배열.

COUNTS = [0] * (+1)
