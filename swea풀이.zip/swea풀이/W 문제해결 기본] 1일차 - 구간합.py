T = int(input())

for tc in range(1, t+1):
    N = int(input())
    arr = list(map(int, input().split()))

    max_v = arr[0] # 첫 원소를 최댓값으로 가정
    min_v = arr[0] # 첫 원소를 최솟값으로 가정

    for i in range(1, n):
        if max_v < arr[i]: 		# arr[i] > max_v (다음 연산식과 비교식 순서를 맞출 것)
            max_v = arr[i]
        if min_v > arr[i]:
            min_v = arr[i]
    
    print(f'#{tc} {max_v-min-v}')


    