# import itertools
# numbers = [i for i in range(1,5)]
# print(list(itertools.combinations(numbers, 2)))

# 다 뽑아야 하는 케이스에 itertools사용. / 가지치기 할 때는 비효율율


# #     # 중복순열  > 중복 조합 > 조합 > 순열
# #     # 중복순열 - 자기자신을 또 뽑는 순열(1,1 2,2 3,3 4,4)

numbers = [i for i in range(1,5)] # [1,2,3,4]
answer = []
N = len(numbers)
visited = [0]*N                         #[]원본과 길이가 같아야함.
M = 3 # 뽑아준개수에 연관. m만큼 되면 탈출.

# # count = 0

# # def perm(cnt): 
# #     # 재귀함수는 무한반복이기 때문에 탈출조건 필요함.
# #     if cnt == M:
# #         print(answer)
# #         count += 1
# #         return
# #         #return none

# #     for i in range(N):   #처음부터 끝까지 돌거야
# #         answer.append(numbers[i])     # 걸렸으면 냅다 뽑아
# #         perm(cnt+1)                   # 다음단계로넘어감
# #         answer.pop()                  # 돌아오면서 뒤의 (,N) 얘 빼주기

# # perm(0)
# # print()

# # def comb(cnt, idx):      #자기자신 포함해서 한칸 더 늘어남 : 인덱스필요.

# #     if cnt == M:
# #         print(answer)
# #         return
    
# #     for i in range(idx, N):
# #         answer.append(numbers[i])
# #         comb(cnt+1, i+1)           #idx만 넘겨주면 안됨. 왜? 범위만 알려주는 거지 숫자값을 의미하는 게 아니기 때문
# #                                     # 중복 하기 싫으면 i 대신 i+1 넣기. 그럼 i+1이 위 range식에 들어감.
# #         answer.pop()
        
# # comb(0,0)


def perm2(cnt):
    if cnt ==M:
        print(answer)
        return
    
    for i in range(N):
        # 중복검사 후 넣기
        if not visited[i]:                      #0이 방문ㄴㄴ. 1이 방문함으로 세팅하면,
            visited[i]=1                        #false면 빈곳이니까 들어감
            answer.append(numbers[i])           
            perm2(cnt+1)
            visited[i]=0
            answer.pop()

perm2()

# map 제너레이터설명,,,
# map(함수, iterable)






