T = int(input())

for tc in range(1, t+1):
    answer = 0                  
    current = 0                         #이 칸이 어디 놓여있나?
    K, N, M = map(int, input().split())
    charges =[int(i) for i in input().split()]
    
    #현 위치에서 바로 도착이 가능하면 끝이다
    # > 바로 도착이 불가능하면 진행한다
    while current+K< N:
        #들어왔다는 것은?
        #아직 도착하지 않았다는 것
        # = current 이동해줘야 한다
        isfind = False
        for idx in range(-1, -len(charges)-1, -1): # 왜 -1이냐면 범위설정할때 ,,,

            #다음 지점을 찾으면 여기 들어갈 것
            if current < charges[idx] <= current+K            # 끝 지점 이하이니
                current = charges[idx]
                answer += 1
                isfind = True
                break                               # 더 찾지마
            
            # if isfind:
            #     break

    if not isfind:
        answer = 0
        break


    print(f'#{tc} {answer}')