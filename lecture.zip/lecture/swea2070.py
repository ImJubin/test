#1. 입력 > T
T = int(input())
#2. T만큼 반복 > TC 진입
for tc in range(T, T+1):
#   numbers 정수화

    numbers = input().split()
    for i in range(len(numbers)):
        numbers[i] = int(numbers[i])
        
#   크기 비교 수 1 > 수 2 ... ">"
#            수 1 = 수 2 ... "="
#            수 1 < 수 2 ... "<"



    if numbers[0] > numbers[1]:
        numbers = "<"
    elif numbers[0] == numbers[1]:
        numbers = "="
    else:
        numbers = ">"
                    
    print(f'#{tc} {numbers}')

#   크기 비교 수 1 > 수 2 ... ">"
#            수 1 = 수 2 ... "="
#            수 1 < 수 2 ... "<"
  
#   
#   출력
    # print(f'#{tc} {}')