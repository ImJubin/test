def generator_test():
    for i in range(1,6):
        yield i
    
generator = generator_test()
# print(dir(generator))

for item in generator:
    print(item)

import itertools
numbers = [1,2,3]

print(list(itertools.combinations(numbers, 2)))

for item in itertools.combinations(numbers, 2):
    print(item)
# "1 2 3 4 5"

# list(map(print,input().split()))

# a = print
# a(5)