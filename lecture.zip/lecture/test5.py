a = "123456"
b = list(map(int,a)) #각 한자리 문자에 대해서 정수화해라.>list>b에넣어주기
print(b)


for char in a:
    print(char)

#사람입니까?

